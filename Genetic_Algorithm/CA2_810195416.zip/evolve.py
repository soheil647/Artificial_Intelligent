
class GA:
    def __init__(self`):